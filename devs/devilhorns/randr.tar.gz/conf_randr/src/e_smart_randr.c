#include "e.h"
#include "e_mod_main.h"
#include "e_smart_randr.h"
#include "e_smart_monitor.h"

/* 'Smart' widget which raps the pan and scrollframe into one */

typedef struct _E_Smart_Data E_Smart_Data;
struct _E_Smart_Data
{
   /* visible flag */
   Eina_Bool visible : 1;

   /* changed flag */
   Eina_Bool changed : 1;

   /* objects which make up this smart widget */
   Evas_Object *o_pan, *o_scroll;
};

typedef struct _E_Smart_Pan_Data E_Smart_Pan_Data;
struct _E_Smart_Pan_Data
{
   /* object geometry */
   Evas_Coord x, y, w, h;

   /* child (pan) geometry */
   Evas_Coord cx, cy, cw, ch;

   /* scrolled position */
   Evas_Coord sx, sy;

   /* list of items (monitors) */
   Eina_List *items;

   /* idler for reconfigure */
   Ecore_Idle_Enterer *idle_enter;
};

/* local function prototypes */
static void _e_smart_add(Evas_Object *obj);
static void _e_smart_del(Evas_Object *obj);
static void _e_smart_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y);
static void _e_smart_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h);
static void _e_smart_show(Evas_Object *obj);
static void _e_smart_hide(Evas_Object *obj);
static void _e_smart_color_set(Evas_Object *obj __UNUSED__, int r __UNUSED__, int g __UNUSED__, int b __UNUSED__, int a __UNUSED__);
static void _e_smart_clip_set(Evas_Object *obj, Evas_Object *clip);
static void _e_smart_clip_unset(Evas_Object *obj);
static void _e_smart_reconfigure(E_Smart_Data *sd);

static Evas_Object *_e_smart_randr_pan_add(Evas *evas);
static void _e_smart_pan_add(Evas_Object *obj);
static void _e_smart_pan_del(Evas_Object *obj);
static void _e_smart_pan_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y);
static void _e_smart_pan_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h);
static void _e_smart_pan_reconfigure(Evas_Object *obj);
static Eina_Bool _e_smart_pan_reconfigure_do(void *data);
static void _e_smart_pan_set(Evas_Object *obj, Evas_Coord x, Evas_Coord y);
static void _e_smart_pan_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y);
static void _e_smart_pan_max_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y);
static void _e_smart_pan_child_size_get(Evas_Object *obj, Evas_Coord *w, Evas_Coord *h);

/* public functions */
Evas_Object *
e_smart_randr_add(Evas *evas)
{
   static Evas_Smart *smart = NULL;
   static const Evas_Smart_Class sc = 
     {
        "smart_monitor", EVAS_SMART_CLASS_VERSION,
        _e_smart_add, _e_smart_del, _e_smart_move, _e_smart_resize,
        _e_smart_show, _e_smart_hide, _e_smart_color_set, 
        _e_smart_clip_set, _e_smart_clip_unset, 
        NULL, NULL, NULL, NULL, NULL, NULL, NULL
     };

   smart = evas_smart_class_new(&sc);
   return evas_object_smart_add(evas, smart);
}

void 
e_smart_randr_monitor_add(Evas_Object *obj, Evas_Object *monitor)
{
   E_Smart_Data *sd;
   E_Smart_Pan_Data *psd;

   if (!monitor) return;
   if (!(sd = evas_object_smart_data_get(obj)))
     return;
   if (!(psd = evas_object_smart_data_get(sd->o_pan)))
     return;

   /* append this monitor to the list of monitors */
   psd->items = eina_list_append(psd->items, monitor);
//   _e_smart_pan_reconfigure(psd);

   /* set changed flag */
   sd->changed = EINA_TRUE;

   /* reconfigure the layout */
   _e_smart_reconfigure(sd);
}

/* local functions */
static void 
_e_smart_add(Evas_Object *obj)
{
   E_Smart_Data *sd;
   Evas *evas;

   if (!(sd = calloc(1, sizeof(E_Smart_Data))))
     return;

   evas = evas_object_evas_get(obj);

   sd->o_pan = _e_smart_randr_pan_add(evas);
   evas_object_smart_member_add(sd->o_pan, obj);

   sd->o_scroll = e_scrollframe_add(evas);
   /* FIXME: Proper theme */
   e_scrollframe_custom_theme_set(sd->o_scroll, "base/theme/widgets", 
                                  "e/conf/wallpaper/main/scrollframe");
   e_scrollframe_extern_pan_set(sd->o_scroll, sd->o_pan, 
                                _e_smart_pan_set, _e_smart_pan_get, 
                                _e_smart_pan_max_get, 
                                _e_smart_pan_child_size_get);
   evas_object_smart_member_add(sd->o_scroll, obj);

   evas_object_smart_data_set(obj, sd);
}

static void 
_e_smart_del(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   evas_object_del(sd->o_pan);
   evas_object_del(sd->o_scroll);

   E_FREE(sd);

   evas_object_smart_data_set(obj, NULL);
}

static void 
_e_smart_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   evas_object_move(sd->o_scroll, x, y);

   sd->changed = EINA_TRUE;
   _e_smart_reconfigure(sd);
}

static void 
_e_smart_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   evas_object_resize(sd->o_scroll, w, h);

   sd->changed = EINA_TRUE;
   _e_smart_reconfigure(sd);
}

static void 
_e_smart_show(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (sd->visible) return;
   evas_object_show(sd->o_scroll);
   sd->visible = EINA_TRUE;
}

static void 
_e_smart_hide(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (!sd->visible) return;
   evas_object_hide(sd->o_scroll);
   sd->visible = EINA_FALSE;
}

static void 
_e_smart_color_set(Evas_Object *obj __UNUSED__, int r __UNUSED__, int g __UNUSED__, int b __UNUSED__, int a __UNUSED__)
{
   /* E_Smart_Data *sd; */

   /* if (!(sd = evas_object_smart_data_get(obj))) */
   /*   return; */
}

static void 
_e_smart_clip_set(Evas_Object *obj, Evas_Object *clip)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   printf("Scroll Clip Set\n");
   evas_object_clip_set(sd->o_scroll, clip);
}

static void 
_e_smart_clip_unset(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   printf("Scroll Clip Unset\n");
   evas_object_clip_unset(sd->o_scroll);
}

static void 
_e_smart_reconfigure(E_Smart_Data *sd)
{
   if ((!sd) || (!sd->changed)) return;

   _e_smart_pan_reconfigure(sd->o_pan);

   sd->changed = EINA_FALSE;
}

static Evas_Object *
_e_smart_randr_pan_add(Evas *evas)
{
   static Evas_Smart *smart = NULL;
   static const Evas_Smart_Class sc = 
     {
        "randr_pan", EVAS_SMART_CLASS_VERSION,
        _e_smart_pan_add, _e_smart_pan_del,
        _e_smart_pan_move, _e_smart_pan_resize,
        NULL, NULL, // show & hide
        NULL, // color set
        NULL, NULL, // clip set & unset
        NULL, NULL, NULL, NULL, NULL, NULL, NULL
     };
   smart = evas_smart_class_new(&sc);
   return evas_object_smart_add(evas, smart);
}

static void 
_e_smart_pan_add(Evas_Object *obj)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = calloc(1, sizeof(E_Smart_Pan_Data))))
     return;

   sd->sx = sd->sy = -1;
   evas_object_smart_data_set(obj, sd);
}

static void 
_e_smart_pan_del(Evas_Object *obj)
{
   E_Smart_Pan_Data *sd;
   Evas_Object *mon;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (sd->idle_enter) ecore_idle_enterer_del(sd->idle_enter);

   EINA_LIST_FREE(sd->items, mon)
     evas_object_del(mon);

   E_FREE(sd);
   evas_object_smart_data_set(obj, NULL);
}

static void 
_e_smart_pan_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if ((sd->x == x) && (sd->y == y)) return;
   sd->x = x;
   sd->y = y;
   _e_smart_pan_reconfigure(obj);
}

static void 
_e_smart_pan_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if ((sd->w == w) && (sd->h == h)) return;
   printf("Pan Resize: %d %d\n", w, h);
   sd->w = w;
   sd->h = h;
   _e_smart_pan_reconfigure(obj);
   evas_object_smart_callback_call(obj, "changed", NULL);
}

static void 
_e_smart_pan_reconfigure(Evas_Object *obj)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;

   if (sd->idle_enter) return;

   sd->idle_enter = 
     ecore_idle_enterer_before_add(_e_smart_pan_reconfigure_do, obj);
}

static Eina_Bool 
_e_smart_pan_reconfigure_do(void *data)
{
   Evas_Object *obj;
   E_Smart_Pan_Data *sd;
   Evas *evas;
   Evas_Coord vw = 0, vh = 0;
   Eina_List *l;
   Evas_Object *mon;

   if (!(obj = data)) return ECORE_CALLBACK_CANCEL;
   if (!(sd = evas_object_smart_data_get(obj)))
     return ECORE_CALLBACK_CANCEL;

   if (sd->cx > (sd->cw - sd->w)) sd->cx = (sd->cw - sd->w);
   if (sd->cy > (sd->ch - sd->h)) sd->cy = (sd->ch - sd->h);
   if (sd->cx < 0) sd->cx = 0;
   if (sd->cy < 0) sd->cy = 0;

   evas = evas_object_evas_get(obj);
   evas_output_viewport_get(evas, NULL, NULL, &vw, &vh);
   printf("Viewport: %d %d\n", vw, vh);

   EINA_LIST_FOREACH(sd->items, l, mon)
     {
        Evas_Coord x, y, w, h;

        e_smart_monitor_geometry_get(mon, &x, &y, &w, &h);
        printf("Monitor Geom: %d %d %d %d\n", x, y, w, h);
        if (x > 0) x /= 10;
        if (y > 0) y /= 10;
        if (w > 0) w /= 10;
        if (h > 0) h /= 10;
        evas_object_move(mon, x, y);
        evas_object_resize(mon, w, h);
        printf("\tMon Obj Pos: %d %d %d %d\n", x, y, w, h);
        /* evas_object_geometry_get(mon, &x, &y, &w, &h); */
        /* printf("\tObj Geom: %d %d %d %d\n", x, y, w, h); */
     }

   return ECORE_CALLBACK_CANCEL;
}

static void 
_e_smart_pan_set(Evas_Object *obj, Evas_Coord x, Evas_Coord y)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (x > (sd->cw - sd->w)) x = (sd->cw - sd->w);
   if (y > (sd->ch - sd->h)) y = (sd->ch - sd->h);
   if (x < 0) x = 0;
   if (y < 0) y = 0;
   if ((sd->cx == x) && (sd->cy == y)) return;
   sd->cx = x;
   sd->cy = y;
   _e_smart_pan_reconfigure(obj);
}

static void 
_e_smart_pan_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (x) *x = sd->cx;
   if (y) *y = sd->cy;
}

static void 
_e_smart_pan_max_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (x)
     {
        if (sd->w < sd->cw) *x = (sd->cw - sd->w);
        else *x = 0;
     }
   if (y)
     {
        if (sd->h < sd->ch) *y = (sd->ch - sd->h);
        else *y = 0;
     }
}

static void 
_e_smart_pan_child_size_get(Evas_Object *obj, Evas_Coord *w, Evas_Coord *h)
{
   E_Smart_Pan_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (w) *w = sd->cw;
   if (h) *h = sd->ch;
}
