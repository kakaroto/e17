#ifdef E_TYPEDEFS
#else
# ifndef E_INT_CONFIG_RANDR_H
#  define E_INT_CONFIG_RANDR_H

E_Config_Dialog *e_int_config_randr(E_Container *con, const char *params __UNUSED__);

# endif
#endif
