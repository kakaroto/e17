#ifdef E_TYPEDEFS
#else
# ifndef E_WIDGET_RANDR_H
#  define E_WIDGET_RANDR_H

Evas_Object *e_widget_randr_add(Evas *evas);
void e_widget_randr_monitor_add(Evas_Object *obj, Evas_Object *mon);

# endif
#endif
