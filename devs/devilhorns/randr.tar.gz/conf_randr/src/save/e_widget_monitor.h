#ifdef E_TYPEDEFS
#else
# ifndef E_WIDGET_MONITOR_H
#  define E_WIDGET_MONITOR_H

Evas_Object *e_widget_monitor_add(Evas *evas, E_Randr_Output_Info *info);

# endif
#endif
