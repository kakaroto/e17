#include "e.h"
#include "e_mod_main.h"
#include "e_widget_randr.h"

/* This is a generic randr widget which will consist of a custom scrollframe 
 * and custom pan object. It will be used to contain X number of monitor 
 * widgets */

/* local structures */
typedef struct _E_Widget_Data E_Widget_Data;
struct _E_Widget_Data
{
   Evas_Object *o_pan, *o_scroll;
};

typedef struct _E_Smart_Data E_Smart_Data;
struct _E_Smart_Data
{
   Eina_List *items;
   Evas_Coord x, y, w, h;
   Evas_Coord cx, cy, cw, ch;
   Ecore_Idle_Enterer *idle_enterer;
};

/* local function prototypes */
static void _e_wid_del_hook(Evas_Object *obj);
static void _e_wid_focus_hook(Evas_Object *obj __UNUSED__);

/* static void _e_wid_focus_steal(void *data, Evas *evas, Evas_Object *obj, void *event); */
static Evas_Object *_e_wid_pan_add(Evas *evas);
static void _e_wid_pan_set(Evas_Object *obj, Evas_Coord x, Evas_Coord y);
static void _e_wid_pan_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y);
static void _e_wid_pan_max_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y);
static void _e_wid_pan_child_size_get(Evas_Object *obj, Evas_Coord *w, Evas_Coord *h);
static void _e_smart_add(Evas_Object *obj);
static void _e_smart_del(Evas_Object *obj);
static void _e_smart_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y);
static void _e_smart_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h);
static void _e_smart_show(Evas_Object *obj __UNUSED__);
static void _e_smart_hide(Evas_Object *obj __UNUSED__);
static void _e_smart_color_set(Evas_Object *obj __UNUSED__, int r __UNUSED__, int g __UNUSED__, int b __UNUSED__, int a __UNUSED__);
static void _e_smart_clip_set(Evas_Object *obj __UNUSED__, Evas_Object *clip __UNUSED__);
static void _e_smart_clip_unset(Evas_Object *obj __UNUSED__);
static void _e_smart_reconfigure(Evas_Object *obj);
static Eina_Bool _e_smart_reconfigure_do(void *data);

Evas_Object *
e_widget_randr_add(Evas *evas)
{
   Evas_Object *obj;
   E_Widget_Data *wd;

   if (!(wd = calloc(1, sizeof(E_Widget_Data))))
     return NULL;

   obj = e_widget_add(evas);
   e_widget_del_hook_set(obj, _e_wid_del_hook);
//   e_widget_focus_hook_set(obj, _e_wid_focus_hook);
   e_widget_data_set(obj, wd);

   wd->o_pan = _e_wid_pan_add(evas);
//   e_widget_sub_object_add(obj, wd->o_pan);
   evas_object_show(wd->o_pan);

   wd->o_scroll = e_scrollframe_add(evas);
   e_scrollframe_custom_theme_set(wd->o_scroll, "base/theme/widgets", 
                                  "e/conf/randr/main/scrollframe");
   e_scrollframe_extern_pan_set(wd->o_scroll, wd->o_pan, 
                                _e_wid_pan_set, _e_wid_pan_get, 
                                _e_wid_pan_max_get, _e_wid_pan_child_size_get);
   evas_object_show(wd->o_scroll);
   e_widget_sub_object_add(obj, wd->o_scroll);

   e_widget_resize_object_set(obj, wd->o_scroll);

   return obj;
}

void 
e_widget_randr_monitor_add(Evas_Object *obj, Evas_Object *mon)
{
   E_Widget_Data *wd;
   E_Smart_Data *sd;

   if (!(wd = e_widget_data_get(obj))) return;

   if (!(sd = evas_object_smart_data_get(wd->o_pan))) return;
   sd->items = eina_list_append(sd->items, mon);

   evas_object_clip_set(mon, evas_object_clip_get(wd->o_pan));

   _e_smart_reconfigure(wd->o_pan);
}

/* local function prototypes */
static void 
_e_wid_del_hook(Evas_Object *obj)
{
   E_Widget_Data *wd;

   if (!(wd = e_widget_data_get(obj))) return;
   if (wd->o_pan) evas_object_del(wd->o_pan);
   if (wd->o_scroll) evas_object_del(wd->o_scroll);

   E_FREE(wd);
}

static void 
_e_wid_focus_hook(Evas_Object *obj __UNUSED__)
{

}

/* static void  */
/* _e_wid_focus_steal(void *data, Evas *evas, Evas_Object *obj, void *event) */
/* { */

/* } */

static Evas_Object *
_e_wid_pan_add(Evas *evas)
{
   static Evas_Smart *smart = NULL;
   static const Evas_Smart_Class sc = 
     {
        "randr_pan", EVAS_SMART_CLASS_VERSION, 
        _e_smart_add, _e_smart_del, 
        _e_smart_move, _e_smart_resize, 
        _e_smart_show, _e_smart_hide, 
        _e_smart_color_set,
        _e_smart_clip_set, _e_smart_clip_unset, 
        NULL, NULL, NULL, NULL, NULL, NULL, NULL
     };

   smart = evas_smart_class_new(&sc);
   return evas_object_smart_add(evas, smart);
}

static void 
_e_wid_pan_set(Evas_Object *obj, Evas_Coord x, Evas_Coord y)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   if (x > (sd->cw - sd->w)) x = (sd->cw - sd->w);
   if (y > (sd->ch - sd->h)) y = (sd->ch - sd->h);
   if (x < 0) x = 0;
   if (y < 0) y = 0;
   if ((sd->cx == x) && (sd->cy == y)) return;
   sd->cx = x;
   sd->cy = y;
   _e_smart_reconfigure(obj);
}

static void 
_e_wid_pan_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   if (x) *x = sd->cx;
   if (y) *y = sd->cy;
}

static void 
_e_wid_pan_max_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   if (x)
     {
        if (sd->w < sd->cw) *x = (sd->cw - sd->w);
        else *x = 0;
     }
   if (y)
     {
        if (sd->h < sd->ch) *y = (sd->ch - sd->h);
        else *y = 0;
     }
}

static void 
_e_wid_pan_child_size_get(Evas_Object *obj, Evas_Coord *w, Evas_Coord *h)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   if (w) *w = sd->cw;
   if (h) *h = sd->ch;
}

static void 
_e_smart_add(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = calloc(1, sizeof(E_Smart_Data)))) return;
   sd->x = sd->y = -1;
   evas_object_smart_data_set(obj, sd);
}

static void 
_e_smart_del(Evas_Object *obj)
{
   E_Smart_Data *sd;
   Evas_Object *mon;

   if (!(sd = evas_object_smart_data_get(obj))) return;

   if (sd->idle_enterer) ecore_idle_enterer_del(sd->idle_enterer);

   EINA_LIST_FREE(sd->items, mon)
     evas_object_del(mon);

   E_FREE(sd);
   evas_object_smart_data_set(obj, NULL);
}

static void 
_e_smart_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   sd->x = x;
   sd->y = y;
   _e_smart_reconfigure(obj);
}

static void 
_e_smart_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   sd->w = w;
   sd->h = h;
   _e_smart_reconfigure(obj);
}

static void 
_e_smart_show(Evas_Object *obj __UNUSED__)
{

}

static void 
_e_smart_hide(Evas_Object *obj __UNUSED__)
{

}

static void 
_e_smart_color_set(Evas_Object *obj __UNUSED__, int r __UNUSED__, int g __UNUSED__, int b __UNUSED__, int a __UNUSED__)
{

}

static void 
_e_smart_clip_set(Evas_Object *obj __UNUSED__, Evas_Object *clip __UNUSED__)
{

}

static void 
_e_smart_clip_unset(Evas_Object *obj __UNUSED__)
{

}

static void 
_e_smart_reconfigure(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj))) return;
   if (sd->idle_enterer) return;
   sd->idle_enterer = 
     ecore_idle_enterer_before_add(_e_smart_reconfigure_do, obj);
}

static Eina_Bool 
_e_smart_reconfigure_do(void *data)
{
   Evas_Object *obj;
   E_Smart_Data *sd;
   Eina_List *l;
   Evas_Object *mon = NULL;
   Eina_Bool redo = EINA_FALSE;
   Eina_Bool changed = EINA_FALSE;
   static Eina_Bool recursion = EINA_FALSE;
   Evas *evas;
   Evas_Coord vw, vh, mw = 0, mh = 0;
   Evas_Coord x = 0, y = 0;

   if (!(obj = data)) return ECORE_CALLBACK_CANCEL;
   if (!(sd = evas_object_smart_data_get(obj))) return ECORE_CALLBACK_CANCEL;

   if (sd->cx > (sd->cw - sd->w)) sd->cx = (sd->cw - sd->w);
   if (sd->cy > (sd->ch - sd->h)) sd->cy = (sd->ch - sd->h);
   if (sd->cx < 0) sd->cx = 0;
   if (sd->cy < 0) sd->cy = 0;

   evas = evas_object_evas_get(obj);
   evas_output_viewport_get(evas, NULL, NULL, &vw, &vh);

   EINA_LIST_FOREACH(sd->items, l, mon)
     {
        int ow, oh;

        if (!mon) continue;

        evas_object_geometry_get(mon, NULL, NULL, &ow, &oh);

        if ((x + ow) > sd->w)
          {
             x = 0;
             y += oh;
          }

        evas_object_move(mon, x, y);
        evas_object_raise(mon);

        /* evas_object_resize(mon, ow, oh); */

        if ((x + ow) > mw) mw = x + ow;
        if ((y + oh) > mh) mh = y + oh;
        x += ow;
     }

   if ((mw != sd->cw) || (mh != sd->ch))
     {
        sd->cw = mw;
        sd->ch = mh;
        if (sd->cx > (sd->cw - sd->w))
          {
             sd->cx = (sd->cw - sd->w);
             redo = EINA_TRUE;
          }
        if (sd->cy > (sd->ch - sd->h))
          {
             sd->cy = (sd->ch - sd->h);
             redo = EINA_TRUE;
          }
        if (sd->cx < 0)
          {
             sd->cx = 0;
             redo = EINA_TRUE;
          }
        if (sd->cy < 0)
          {
             sd->cy = 0;
             redo = EINA_TRUE;
          }
        if (redo)
          {
             recursion = EINA_TRUE;
             _e_smart_reconfigure_do(obj);
             recursion = EINA_FALSE;
          }
        changed = EINA_TRUE;
     }

   if (changed)
     evas_object_smart_callback_call(obj, "changed", NULL);

   if (!recursion) 
     sd->idle_enterer = NULL;

   return ECORE_CALLBACK_CANCEL;
}
