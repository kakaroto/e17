#include "e.h"
#include "e_mod_main.h"
#include "e_widget_monitor.h"

/* local structures */
typedef struct _E_Widget_Data E_Widget_Data;
struct _E_Widget_Data
{
   Evas_Object *o_base;
   Evas_Object *o_thumb;
   Evas_Object *o_img;
   E_Randr_Output_Info *info;
   Eina_Bool selected : 1;
};

/* local function prototypes */
static void _e_wid_del_hook(Evas_Object *obj);
static void _e_wid_cb_select(void *data __UNUSED__, Evas *evas, Evas_Object *obj, void *event);

Evas_Object *
e_widget_monitor_add(Evas *evas, E_Randr_Output_Info *info)
{
   Evas_Object *obj;
   E_Widget_Data *wd;
   const char *file, *name;
   int ow, oh;

   if (!(wd = calloc(1, sizeof(E_Widget_Data)))) return NULL;

   wd->info = info;
   wd->selected = EINA_FALSE;

   obj = e_widget_add(evas);
   e_widget_del_hook_set(obj, _e_wid_del_hook);
   e_widget_data_set(obj, wd);

   printf("Monitor Size: %d %d\n", info->monitor->size_mm.width, 
          info->monitor->size_mm.height);
   printf("Crtc Size: %d %d\n", info->crtc->geometry.w, 
          info->crtc->geometry.h);

   ow = (info->crtc->geometry.w / 4);
   oh = (info->crtc->geometry.h / 4);

   wd->o_base = edje_object_add(evas);
   if (!e_theme_edje_object_set(wd->o_base, "base/theme/widgets", 
                                "e/conf/randr/main/monitor"))
     {
        char buff[PATH_MAX];

        snprintf(buff, sizeof(buff), "%s/e-module-conf_randr.edj", mod_dir);
        edje_object_file_set(wd->o_base, buff, "e/conf/randr/main/monitor");
     }
   evas_object_event_callback_add(wd->o_base, EVAS_CALLBACK_MOUSE_DOWN, 
                                  _e_wid_cb_select, NULL);
   e_widget_sub_object_add(obj, wd->o_base);
   e_widget_resize_object_set(obj, wd->o_base);
   evas_object_show(wd->o_base);

   /* E_Zone *zone; */
   /* zone = e_util_zone_current_get(e_manager_current_get()); */

   wd->o_thumb = e_livethumb_add(evas);
   e_livethumb_vsize_set(wd->o_thumb, ow, oh);
   edje_object_part_swallow(wd->o_base, "e.swallow.preview", wd->o_thumb);
   e_widget_sub_object_add(obj, wd->o_thumb);

   /* FIXME: Remove hard-code */
   file = e_bg_file_get(0, 0, 0, 0);

   if (!(wd->o_img = e_livethumb_thumb_get(wd->o_thumb)))
     wd->o_img = edje_object_add(e_livethumb_evas_get(wd->o_thumb));
   edje_object_file_set(wd->o_img, file, "e/desktop/background");
   e_livethumb_thumb_set(wd->o_thumb, wd->o_img);
//   e_widget_sub_object_add(obj, wd->o_img);

   if (info)
     {
        if (info->monitor)
          name = ecore_x_randr_edid_display_name_get(info->monitor->edid, 
                                                     info->monitor->edid_length);
        if ((!name) && (info->name))
          name = info->name;
     }

   if (name)
     edje_object_part_text_set(wd->o_base, "e.text.name", name);

   /* edje_object_size_min_calc(wd->o_base, &ow, &oh); */
   /* printf("Mon Min Size: %d %d\n", ow, oh); */

   e_widget_size_min_set(obj, ow, oh);
   e_widget_size_min_resize(obj);

   return obj;
}

/* local functions */
static void 
_e_wid_del_hook(Evas_Object *obj)
{
   E_Widget_Data *wd;

   if (!(wd = e_widget_data_get(obj))) return;

   evas_object_event_callback_del(wd->o_base, EVAS_CALLBACK_MOUSE_DOWN, 
                                  _e_wid_cb_select);

   if (wd->o_thumb) evas_object_del(wd->o_thumb);
   if (wd->o_img) evas_object_del(wd->o_img);
   if (wd->o_base) evas_object_del(wd->o_base);

   E_FREE(wd);
}

static void 
_e_wid_cb_select(void *data __UNUSED__, Evas *evas __UNUSED__, Evas_Object *obj, void *event __UNUSED__)
{
   E_Widget_Data *wd;

   printf("Monitor CB Select\n");
   if (!(wd = e_widget_data_get(obj))) return;
   if (wd->selected)
     {
        edje_object_signal_emit(wd->o_base, "e,state,unselected", "e");
        wd->selected = EINA_FALSE;
     }
   else
     {
        edje_object_signal_emit(wd->o_base, "e,state,selected", "e");
        wd->selected = EINA_TRUE;
     }
}
