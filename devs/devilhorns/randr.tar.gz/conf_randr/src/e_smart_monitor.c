#include "e.h"
#include "e_mod_main.h"
#include "e_smart_monitor.h"

typedef struct _E_Smart_Data E_Smart_Data;
struct _E_Smart_Data
{
   /* object geometry */
   Evas_Coord x, y, w, h;

   /* visible flag */
   Eina_Bool visible : 1;

   /* changed flag */
   Eina_Bool changed : 1;

   /* base object */
   Evas_Object *o_base;

   /* livethumb for background */

   /* Randr info struc for this monitor */
   E_Randr_Output_Info *info;
};

/* local function prototypes */
static void _e_smart_add(Evas_Object *obj);
static void _e_smart_del(Evas_Object *obj);
static void _e_smart_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y);
static void _e_smart_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h);
static void _e_smart_show(Evas_Object *obj);
static void _e_smart_hide(Evas_Object *obj);
static void _e_smart_color_set(Evas_Object *obj __UNUSED__, int r __UNUSED__, int g __UNUSED__, int b __UNUSED__, int a __UNUSED__);
static void _e_smart_clip_set(Evas_Object *obj, Evas_Object *clip);
static void _e_smart_clip_unset(Evas_Object *obj);
static void _e_smart_reconfigure(E_Smart_Data *sd);

/* public functions */
Evas_Object *
e_smart_monitor_add(Evas *evas, E_Randr_Output_Info *info)
{
   E_Smart_Data *sd;
   Evas_Object *mon;
   static Evas_Smart *smart = NULL;
   static const Evas_Smart_Class sc = 
     {
        "smart_randr", EVAS_SMART_CLASS_VERSION,
        _e_smart_add, _e_smart_del, _e_smart_move, _e_smart_resize,
        _e_smart_show, _e_smart_hide, _e_smart_color_set, 
        _e_smart_clip_set, _e_smart_clip_unset, 
        NULL, NULL, NULL, NULL, NULL, NULL, NULL
     };

   smart = evas_smart_class_new(&sc);

   if (!(mon = evas_object_smart_add(evas, smart)))
     {
        printf("Smart Object Add Failed !!\n");
        return NULL;
     }

   if (!(sd = evas_object_smart_data_get(mon)))
     {
        printf("Smart Data Get Failed !!\n");
        evas_object_del(mon);
        return NULL;
     }

   sd->info = info;

   return mon;
}

E_Randr_Output_Info *
e_smart_monitor_info_get(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!obj) return NULL;
   if (!(sd = evas_object_smart_data_get(obj)))
     return NULL;

   return sd->info;
}

void 
e_smart_monitor_geometry_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h)
{
   E_Smart_Data *sd;

   if (!obj) return;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (!sd->info) return;

   if (sd->info->crtc)
     {
        if (x) *x = sd->info->crtc->geometry.x;
        if (y) *y = sd->info->crtc->geometry.y;
        if (w) *w = sd->info->crtc->geometry.w;
        if (h) *h = sd->info->crtc->geometry.h;
     }
   else 
     {
        if (x) *x = 0;
        if (y) *y = 0;
        if (w) *x = 0;
        if (h) *h = 0;
        if (sd->info->monitor)
          {
             if (w) *w = sd->info->monitor->size_mm.width;
             if (h) *h = sd->info->monitor->size_mm.height;
          }
     }
}

/* local functions */
static void 
_e_smart_add(Evas_Object *obj)
{
   E_Smart_Data *sd;
   Evas *evas;

   if (!(sd = calloc(1, sizeof(E_Smart_Data))))
     return;

   evas = evas_object_evas_get(obj);

   sd->o_base = edje_object_add(evas);
   if (!e_theme_edje_object_set(sd->o_base, "base/theme/widgets", 
                                "e/conf/randr/main/monitor"))
     {
        char buff[PATH_MAX];

        snprintf(buff, sizeof(buff), "%s/e-module-conf_randr.edj", mod_dir);
        edje_object_file_set(sd->o_base, buff, "e/conf/randr/main/monitor");
     }
   /* evas_object_move(sd->o_base, 0, 0); */
   /* evas_object_resize(sd->o_base, 100, 100); */
   evas_object_smart_member_add(sd->o_base, obj);

   evas_object_smart_data_set(obj, sd);
}

static void 
_e_smart_del(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   evas_object_del(sd->o_base);

   E_FREE(sd);

   evas_object_smart_data_set(obj, NULL);
}

static void 
_e_smart_move(Evas_Object *obj, Evas_Coord x, Evas_Coord y)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if ((sd->x == x) && (sd->y == y)) return;
   sd->x = x;
   sd->y = y;

   printf("Smart Monitor Move: %d %d\n", x, y);
   evas_object_move(sd->o_base, x, y);
}

static void 
_e_smart_resize(Evas_Object *obj, Evas_Coord w, Evas_Coord h)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if ((sd->w == w) && (sd->h == h)) return;
   sd->w = w;
   sd->h = h;

   printf("Smart Monitor Resize: %d %d\n", w, h);
   evas_object_resize(sd->o_base, w, h);

   _e_smart_reconfigure(sd);
}

static void 
_e_smart_show(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (sd->visible) return;
   printf("Smart Monitor Show\n");
   evas_object_show(sd->o_base);
   sd->visible = EINA_TRUE;
}

static void 
_e_smart_hide(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   if (!sd->visible) return;
   printf("Smart Monitor Hide\n");
   evas_object_hide(sd->o_base);
   sd->visible = EINA_FALSE;
}

static void 
_e_smart_color_set(Evas_Object *obj __UNUSED__, int r __UNUSED__, int g __UNUSED__, int b __UNUSED__, int a __UNUSED__)
{
   /* E_Smart_Data *sd; */

   /* if (!(sd = evas_object_smart_data_get(obj))) */
   /*   return; */
}

static void 
_e_smart_clip_set(Evas_Object *obj, Evas_Object *clip)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   printf("Smart Monitor Clip Set\n");
   evas_object_clip_set(sd->o_base, clip);
}

static void 
_e_smart_clip_unset(Evas_Object *obj)
{
   E_Smart_Data *sd;

   if (!(sd = evas_object_smart_data_get(obj)))
     return;

   printf("Smart Monitor Clip Unset\n");
   evas_object_clip_unset(sd->o_base);
}

static void 
_e_smart_reconfigure(E_Smart_Data *sd)
{
   if (!sd->changed) return;
   sd->changed = EINA_FALSE;
}
