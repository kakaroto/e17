#ifdef E_TYPEDEFS
#else
# ifndef E_SMART_MONITOR_H
#  define E_SMART_MONITOR_H

Evas_Object *e_smart_monitor_add(Evas *evas, E_Randr_Output_Info *info);
void e_smart_monitor_geometry_get(Evas_Object *obj, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h);

# endif
#endif
