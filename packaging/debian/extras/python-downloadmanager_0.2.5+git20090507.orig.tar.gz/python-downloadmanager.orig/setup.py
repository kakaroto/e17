
from setuptools import setup, find_packages


long_description = """
Classes to download contents from the web using the DownloadManager
daemon.
"""


setup(name = 'python-downloadmanager',
      version = '0.2.5',
      license = 'GPL',
      author='Kenneth Christiansen / Leonardo Sobral Cunha',
      author_email='kenneth.christiansen@gmail.com / leonardo.cunha@openbossa.org',
      description = 'Python-based DownloadManager',
      long_description = long_description,
      keywords = 'python download',
      packages = find_packages(),
      zip_safe = False,
      scripts = [
          "downloadmanager/downloadmanager",
      ],
      data_files=[('share/dbus-1/services', ['downloadmanager.service'])],
      )
