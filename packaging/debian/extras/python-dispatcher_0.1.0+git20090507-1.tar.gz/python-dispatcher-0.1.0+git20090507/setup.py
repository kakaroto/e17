
from setuptools import setup, find_packages


trove_classifiers = [
    "Development Status :: 3 - Alpha",
    "Environment :: Console :: Framebuffer",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: BSD License",
    "Operating System :: MacOS :: MacOS X",
    "Operating System :: POSIX",
    "Programming Language :: Python",
    "Topic :: Software Development :: Libraries :: Python Modules",
    ]


long_description = """
Utilities to dispatch methods to be executed in different threads.

This module provides some classes and decorators to transparently execute
methods in the correct thread context.
"""


setup(name = 'python-dispatcher',
      version = '0.1.0',
      license = 'BSD',
      author='Ulisses Furquim',
      author_email='ulissesf@gmail.com',
      description = 'Python utilities to work with threads.',
      long_description = long_description,
      keywords = 'python thread context method callback',
      classifiers = trove_classifiers,
      packages = find_packages(),
      zip_safe=False,
      )
