#
# This file is part of Python Terra
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

import ecore
import threading
import logging
from dispatcher import Dispatcher

from singleton import Singleton


log = logging.getLogger("terra.core.threads")


class ThreadsManager(Singleton):
    def __init__(self):
        Singleton.__init__(self)
        self._lock = threading.Lock()
        self._next_thr = 0
        self._setup_dispatcher()

    def _run_callbacks(self, *ignored):
        try:
            self.disp.run_cbs()
        except:
            log.debug_error("error in threads manager's dispatcher, "
                            "skipping callbacks ...", exc_info=True)
            return False

        return True

    def _setup_dispatcher(self):
        self.thr_name = "terra-main-thr"
        threading.currentThread().setName(self.thr_name)

        self.disp = Dispatcher()
        self._fd_handler = ecore.fd_handler_add(self.disp.in_fd,
                                                ecore.ECORE_FD_READ | \
                                                ecore.ECORE_FD_ERROR,
                                                self._run_callbacks)

    def _next_worker_thr_name(self):
        self._lock.acquire()
        name = "terra-worker-thr-%d" % self._next_thr
        self._next_thr += 1             # FIXME: maybe some check here?
        self._lock.release()

        return name

    def next_worker_thread(self, func):
        name = self._next_worker_thr_name()
        return threading.Thread(name=name, target=func)
