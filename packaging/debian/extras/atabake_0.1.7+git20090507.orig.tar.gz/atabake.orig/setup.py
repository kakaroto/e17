
from setuptools import setup, find_packages


long_description = """
Media Engine Framework to help media applications playing contents
"""


setup(name = 'atabake',
      version = '0.1.7',
      license = 'GPL',
      author='Artur Duque de Souza / Leonardo Sobral Cunha',
      author_email='artur.souza@openbossa.org',
      description = 'Media Engine Framework',
      long_description = long_description,
      keywords = 'python media engine',
      package_dir = {'atabake': 'src/atabake'},
      packages = ['atabake', 'atabake.lib', 'atabake.players'],
      scripts = [
        "src/atabake/atabake",
        ],
      data_files=[('share/dbus-1/services', ['src/atabake.service']),
                  ('share/atabake', ['src/atabake/data/ignore_keys.conf'])],
      zip_safe=False,
      )
