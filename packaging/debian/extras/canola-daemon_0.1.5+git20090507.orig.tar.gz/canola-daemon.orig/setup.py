
from setuptools import setup, find_packages


long_description = """
Canola Daemon was developed to watch folders and scan
them for media using lightmediascanner
"""


setup(name = 'canola-daemon',
      version = '0.1.5',
      license = 'GPL2',
      author='Artur Duque de Souza',
      author_email='artur.souza@openbossa.org',
      description = 'Daemon to watch folders',
      long_description = long_description,
      keywords = 'python media scanner canola',
      package_dir = {'canolad': 'src/canolad'},
      packages = ['canolad'],
      scripts = [
        "src/canolad/canolad",
        ],
      data_files=[('share/dbus-1/services', ['src/canolad.service'])],
      zip_safe=False,
      )
