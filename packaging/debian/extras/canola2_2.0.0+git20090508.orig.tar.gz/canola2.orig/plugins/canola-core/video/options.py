#
# This file is part of Canola
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#          Eduardo Lima (Etrunko) <eduardo.lima@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

import logging
log = logging.getLogger("plugins.canola-core.video.player.options")

from terra.core.manager import Manager

mger = Manager()
OptionsModelFolder = mger.get_class("Model/Options/Folder")
OptionsActionModel = mger.get_class("Model/Options/Action")


class VideoListOptionsModelFolder(OptionsModelFolder):
    terra_type = "Model/Options/Folder/Video/Local"
    title = "Video Options"


class VideoPlayerOptionsModel(OptionsModelFolder):
    terra_type = "Model/Options/Folder/Player/Video"
    title = "Video Options"

    position = None


class GenerateThumbnailOptionModel(OptionsActionModel):
    terra_type = "Model/Options/Folder/Player/Video/GenerateThumbnail"
    name = "Generate thumb"

    def execute(self):
        log.info("TODO: Generate thumbnail for video %s at position %d.",
                 self.screen_controller.model.uri, self.parent.position)
