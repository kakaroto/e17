#
# This file is part of Canola
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#          Eduardo Lima (Etrunko) <eduardo.lima@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

from terra.core.terra_object import TerraObject
from terra.ui.base import EdjeWidget, PluginEdjeWidget

__all__ = ("DefaultIcon", "DefaultPluginIcon",)


class DefaultIcon(EdjeWidget, TerraObject):
    terra_type = "Icon"
    icon = "icon/main_item/applications" # XXX

    def __init__(self, parent):
        TerraObject.__init__(self)
        EdjeWidget.__init__(self, parent.evas, self.icon, parent)


class DefaultPluginIcon(PluginEdjeWidget, TerraObject):
    terra_type = "Icon/Plugin"
    icon = None

    def __init__(self, parent):
        assert self.icon is not None
        TerraObject.__init__(self)
        PluginEdjeWidget.__init__(self, parent.evas, self.icon, parent)

