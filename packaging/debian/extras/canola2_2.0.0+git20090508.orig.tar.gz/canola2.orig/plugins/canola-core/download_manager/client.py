#
# This file is part of Canola
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#          Eduardo Lima (Etrunko) <eduardo.lima@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

from terra.core.singleton import Singleton
from terra.core.plugin_prefs import PluginPrefs
from terra.core.terra_object import TerraObject
from downloadmanager.client import DownloadManager


class SingletonDownloadManager(Singleton, DownloadManager, TerraObject):
    terra_type = "DownloadManager"

    def __init__(self):
        prefs = PluginPrefs("settings")
        limit = prefs.get('concurrent_download_limit') or 3

        Singleton.__init__(self)
        DownloadManager.__init__(self, limit)

        self.default_dir = prefs.get("temp_dir", "/tmp")
