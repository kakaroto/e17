#
# This file is part of Canola
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#          Eduardo Lima (Etrunko) <eduardo.lima@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

from terra.core.model import Model

__all__ = ("RemotePlayerModel",)

# dummy Model to call our RemotePlayer
class RemotePlayerModel(Model):
    terra_type = "Model/Notify/RemotePlayer"

    def __init__(self, name, answer_callback=None):
        Model.__init__(self, name)
        self.answer_callback = answer_callback
