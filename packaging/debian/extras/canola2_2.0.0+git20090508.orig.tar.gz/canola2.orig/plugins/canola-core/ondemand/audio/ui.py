#
# This file is part of Canola
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#          Eduardo Lima (Etrunko) <eduardo.lima@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

from logging import getLogger

from terra.core.manager import Manager

mger = Manager()
ScrollableTextBlock = mger.get_class("Widget/ScrollableTextBlock")
BasicPanelController = mger.get_class("Controller/BasicPanel")
AudioPlayerController = mger.get_class("Controller/Media/Audio")
OnDemandPlayerOptionsModel = \
mger.get_class("Model/Options/Folder/Player/OnDemand")

log = getLogger("plugins.canola-core.ondemand.audio.ui")

class OnDemandAudioPlayerController(AudioPlayerController):
    terra_type = "Controller/Media/Audio/OnDemand"
    name = "podcast"

    def play(self):
        # On demand audio playback always go to the last position
        # if one exists
        self.model.start_pos = self.model.last_pos
        self.model.unheard = False
        AudioPlayerController.play(self)

    def prev(self):
        self.model.last_pos = self.pos
        AudioPlayerController.prev(self)

    def next(self):
        self.model.last_pos = self.pos
        AudioPlayerController.next(self)

    def delete(self):
        self.model.last_pos = self.pos
        AudioPlayerController.delete(self)

    def options_model_get(self):
        return OnDemandPlayerOptionsModel(None, self)
