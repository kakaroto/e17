
from setuptools import setup, find_packages


setup(name = 'python-terra',
      version = '0.1.9',
      author='Ulisses Furquim',
      maintainer='Caio Marcelo de Oliveira Filho',
      maintainer_email='caio.oliveira@openbossa.org',
      description = 'Framework to build Canola-like applications.',
      keywords = 'python canola plugin framework',
      packages = find_packages(),
      scripts = [
        "bin/terra-get-prefs",
        "bin/terra-install-collection",
        "bin/terra-enable-plugin",
        "bin/terra-disable-plugin",
        "bin/terra-list-plugins",
        "bin/terra-rescan-collections",
        "bin/terra-set-prefs",
        "bin/terra-uninstall-collection",
        ],
      zip_safe=False,
      )
