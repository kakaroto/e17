#
# This file is part of Python Terra
# Copyright (C) 2007-2009 Instituto Nokia de Tecnologia
# Contact: Renato Chencarek <renato.chencarek@openbossa.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

from subprocess import Popen, PIPE
import os

##HACK FIXME
def cli(command_line, nice, args):
    """Run <command_line> in a separated process with niceness <nice>.
       Returns a tuple (stdin, stdout, stderr)
    """

    cmd = [command_line]
    cmd.extend(args)
    try:
        proc = Popen(cmd, bufsize=1024, stdin=PIPE, stdout=PIPE, stderr=PIPE, close_fds=True)
    except:
        return None, None, None, None
    os.system("renice %d -p %d" % (nice, proc.pid))
    return proc.pid, proc.stdin, proc.stdout, proc.stderr
