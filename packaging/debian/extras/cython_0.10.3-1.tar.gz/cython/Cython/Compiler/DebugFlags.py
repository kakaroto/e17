debug_disposal_code = 0
debug_temp_alloc = 0
debug_coercion = 0

