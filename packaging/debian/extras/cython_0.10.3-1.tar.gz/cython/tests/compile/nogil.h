void e1(void);
void *e2(void);
