
rotator_cup() {
INFILE=$1
OUTFILE=$2
ANGLE=0
for i in `seq 0 59`; do
    echo $i $ANGLE
    if [ $i -lt 10 ]; then
	imlib2_convert -rotate $ANGLE -antialias -dither \
		 -geometry 64x64 $INFILE $OUTFILE"0"$i".png"
    else
	imlib2_convert -rotate $ANGLE -antialias -dither \
		-geometry 64x64 $INFILE $OUTFILE$i".png"
    fi
    ANGLE=`expr $ANGLE + 6`
done

}
for i in ../hour ../minutes ../seconds; do
    if [ ! -d $i ]; then
	mkdir $i
    fi
done

rotator_cup "hour.cursor.png" "hours/hour.cursor."
rotator_cup "minutes.cursor.png" "minutes/minutes.cursor."
rotator_cup "seconds.cursor.png" "seconds/seconds.cursor."
