#!/bin/sh -e
edje_cc -v -id ./images -fd ./fonts expedition.edc expedition.eet
