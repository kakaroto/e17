#!/bin/sh -e
edje_cc -fd ./fonts digital.edc digital.eet
