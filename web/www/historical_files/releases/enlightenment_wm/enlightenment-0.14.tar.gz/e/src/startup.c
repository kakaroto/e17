
#include "E.h"

int
AddEToFile(char *file)
{
   FILE               *f1, *f2;
   char                tmp[2048], s[2048];
   char               *s1, *s2;
   char                hase = 0;
   char                foundwm = 0;
   char               *wms[] =
   {
   "wmaker", "afterstep", "fvwm", "fvwm2", "twm", "mwm", "vtwm", "ctwm", "gwm",
      "mlvwm", "kwm", "olwm", "wm2", "wmx", "olvwm", "9wm", "blackbox", "awm", "uwm",
      "amiwm", "dtwm", "4dwm", "scwm", "fvwm95", "fvwm95-2", "tvtwm", "bowman",
      "qwm", "icewm", "qvwm"
   };
   int                 wmnum = 30;
   int                 i;

   EDBUG(8, "AddEToFile");
   if (!exists(file))
      EDBUG_RETURN(0);

   Esnprintf(tmp, 2048, "/tmp/estrt_%i", time(NULL));
   f1 = fopen(file, "r");
   if (!f1)
      EDBUG_RETURN(0);
   f2 = fopen(tmp, "w");
   if (!f2)
     {
	fclose(f1);
	EDBUG_RETURN(0);
     }
   while (fgets(s, 2048, f1))
     {
	s1 = strstr(s, "enlightenment");
	if (s1)
	  {
	     s2 = strstr(s, "#");
	     if (((!s2) || (s1 < s2)) && (!foundwm))
		hase = 1;
	  }
	for (i = 0; i < wmnum; i++)
	  {
	     s1 = strstr(s, wms[i]);
	     if (s1)
	       {
		  s2 = strstr(s, "#");
		  if ((!s2) || (s1 < s2))
		    {
		       fprintf(f2, "#%s", s);
		       fprintf(f2, "\n# Enlightenment inserted Execution string here\n");
		       fprintf(f2, "%s/bin/enlightenment\n\n", ENLIGHTENMENT_ROOT);
		       foundwm = 1;
		       i = wmnum + 1;
		    }
	       }
	  }
	if (i <= wmnum)
	   fprintf(f2, "%s", s);
     }
   fclose(f1);
   fclose(f2);
   if (!foundwm)
     {
	f1 = fopen(file, "r");
	if (!f1)
	   EDBUG_RETURN(0);
	f2 = fopen(tmp, "w");
	if (!f2)
	  {
	     fclose(f1);
	     EDBUG_RETURN(0);
	  }
	fprintf(f2, "\n# Enlightenment inserted Execution string here\n");
	fprintf(f2, "%s/bin/enlightenment\n\n", ENLIGHTENMENT_ROOT);
	while (fgets(s, 2048, f1))
	   fprintf(f2, "%s", s);
	fclose(f1);
	fclose(f2);
     }
   if (!hase)
      cp(tmp, file);
   rm(tmp);
   EDBUG_RETURN(1);
}

int
CreateEFile(char *file)
{
   FILE               *f;

   EDBUG(8, "CreateEFile");
   f = fopen(file, "w");
   if (!f)
      EDBUG_RETURN(0);
   fprintf(f, "# Enlightenment inserted Execution string here\n");
   fprintf(f, "%s/bin/enlightenment\n", ENLIGHTENMENT_ROOT);
   fclose(f);
   EDBUG_RETURN(1);
}

void
AddE()
{
   char               *h;
   char                s[1024];
   int                 val;

   EDBUG(6, "AddE");
   val = 0;
   h = homedir(getuid());
   Esnprintf(s, 1024, "%s/.xsession", h);
   val |= AddEToFile(s);
   Esnprintf(s, 1024, "%s/.xinitrc", h);
   val |= AddEToFile(s);
   Esnprintf(s, 1024, "%s/.Xclients", h);
   val |= AddEToFile(s);
   if (!val)
     {
	Esnprintf(s, 1024, "%s/.xsession", h);
	CreateEFile(s);
	Esnprintf(s, 1024, "%s/.xinitrc", h);
	CreateEFile(s);
	Esnprintf(s, 1024, "%s/.Xclients", h);
	CreateEFile(s);
     }
   Efree(h);
   EDBUG_RETURN_;
}
