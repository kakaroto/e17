#include "E.h"

void
SetupInit()
{
   int                 r, g, b;

   EDBUG(5, "SetupInit");
   init_win = ECreateWindow(root.win, 0, 0, root.w, root.h, 0);
   r = init_conf.bgcolor.r;
   g = init_conf.bgcolor.g;
   b = init_conf.bgcolor.b;
   init_conf.bgcolor.pixel = Imlib_best_color_match(id, &r, &g, &b);
   XSetWindowBackground(disp, init_win, init_conf.bgcolor.pixel);
   XMapWindow(disp, init_win);
   XSync(disp, False);
   EDBUG_RETURN_;
}
