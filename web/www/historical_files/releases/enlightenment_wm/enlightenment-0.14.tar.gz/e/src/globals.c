#include "E.h"

Display            *disp;
ImlibData          *id;
ImlibData          *ird;
FnlibData          *fd;
List                lists;
int                 event_base_shape;
Window              comms_win;
Root                root;
int                 (*(ActionFunctions[ACTION_NUMBEROF])) (void *);
EMode               mode;
Desktops            desks;
Window              grab_window;
Window              init_win;
InitConfig          init_conf;
int                 deskorder[32];
int                 sound_fd;
char                themepath[FILEPATH_LEN_MAX];
char               *command;
char                mustdel;

#ifdef DEBUG
int                 call_level;
int                 debug_level;

#endif
