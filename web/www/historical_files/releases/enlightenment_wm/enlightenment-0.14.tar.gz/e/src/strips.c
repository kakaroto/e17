#include "E.h"

Strip              *
CreateStrip(char *name)
{
   EDBUG(5, "CreateStrip");
   EDBUG_RETURN(NULL);
}

void
DestroyStrip(Strip * s)
{
   EDBUG(5, "DestroyStrip");
   EDBUG_RETURN_;
}

void
RotateStripTo(Strip * s, char rot)
{
   EDBUG(3, "RotateStripTo");
   EDBUG_RETURN_;
}

void
MoveStripTo(Strip * s, int x, int y)
{
   EDBUG(3, "MoveStripTo");
   EDBUG_RETURN_;
}

void
ShowStrip(Strip * s)
{
   EDBUG(3, "ShowStrip");
   EDBUG_RETURN_;
}

void
HideStrip(Strip * s)
{
   EDBUG(3, "HideStrip");
   EDBUG_RETURN_;
}

void
RemoveButtonFromStrip(Strip * s, Button * b)
{
   EDBUG(3, "RemoveButtonFromStrip");
   EDBUG_RETURN_;
}

void
AddButtonToStrip(Strip * s, Button * b, int x, int y)
{
   EDBUG(3, "AddButtonToStrip");
   EDBUG_RETURN_;
}

void
RepackStrip(Strip * s)
{
   EDBUG(4, "RepackStrip");
   EDBUG_RETURN_;
}

Strip              *
IsInStrip(int x, int y)
{
   EDBUG(4, "IsInStrip");
   EDBUG_RETURN(NULL);
}
