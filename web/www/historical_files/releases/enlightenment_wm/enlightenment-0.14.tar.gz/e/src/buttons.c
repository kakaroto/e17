#include "E.h"

Button             *
CreateButton(char *name, ImageClass * iclass, ActionClass * aclass,
	     char ontop, int flags, int minw, int maxw, int minh,
	     int maxh, int xo, int yo, int xa, int xr, int ya, int yr,
	     int xsr, int xsa, int ysr, int ysa, char simg, int desk,
	     char sticky)
{
   Button             *b;

   EDBUG(5, "CreateButton");
   b = Emalloc(sizeof(Button));

   b->name = duplicate(name);
   b->iclass = iclass;
   b->aclass = aclass;
   b->ontop = ontop;
   b->flags = flags;
   b->sticky = sticky;
   b->desktop = desk;
   b->visible = 0;
   b->geom.width.min = minw;
   b->geom.width.max = maxw;
   b->geom.height.min = minh;
   b->geom.height.max = maxh;
   b->geom.xorigin = xo;
   b->geom.yorigin = yo;
   b->geom.xabs = xa;
   b->geom.xrel = xr;
   b->geom.yabs = ya;
   b->geom.yrel = yr;
   b->geom.xsizeabs = xsa;
   b->geom.xsizerel = xsr;
   b->geom.ysizeabs = ysa;
   b->geom.ysizerel = ysr;
   b->geom.size_from_image = simg;

   b->win = ECreateWindow(desks.desk[desk & 0x1f].win, -100, -100, 50, 50, 0);
   XSelectInput(disp, b->win,
		KeyPressMask | KeyReleaseMask |
		ButtonPressMask | ButtonReleaseMask |
		EnterWindowMask | LeaveWindowMask | PointerMotionMask);
   b->x = -1;
   b->y = -1;
   b->w = -1;
   b->h = -1;
   b->cx = -10;
   b->cy = -10;
   b->cw = -10;
   b->ch = -10;
   b->state = 0;
   b->expose = 0;

   if (!b->iclass)
      b->iclass = FindItem("__FALLBACK_ICLASS", 0, LIST_FINDBY_NAME, LIST_TYPE_ICLASS);

   EDBUG_RETURN(b);
}

void
DestroyButton(Button * b)
{
   EDBUG(5, "DestroyButton");
   if (!b)
      EDBUG_RETURN_;
   if (b->name)
      Efree(b->name);
   if (b->win)
      XDestroyWindow(disp, b->win);
   Efree(b);
   EDBUG_RETURN_;
}

void
CalcButton(Button * b)
{
   int                 w, h, x, y, xo, yo;
   ImlibImage         *im;

   EDBUG(4, "CalcButton");
   x = 0;
   y = 0;
   w = 32;
   h = 32;
   if (b->geom.size_from_image)
     {
	if ((b->iclass) && (b->iclass->norm.normal->im_file))
	  {
	     im = ELoadImage(b->iclass->norm.normal->im_file);
	     if (im)
	       {
		  w = im->rgb_width;
		  h = im->rgb_height;
		  Imlib_destroy_image(id, im);
	       }
	     else
	       {
		  w = 32;
		  h = 32;
	       }
	  }
	else
	  {
	     if (!b->iclass)
		b->iclass = FindItem("__FALLBACK_ICLASS", 0, LIST_FINDBY_NAME, LIST_TYPE_ICLASS);
	     w = 32;
	     h = 32;
	  }
     }
   else
     {
	w = ((b->geom.xsizerel * root.w) >> 10) + b->geom.xsizeabs;
	h = ((b->geom.ysizerel * root.h) >> 10) + b->geom.ysizeabs;
     }
   if (w > b->geom.width.max)
      w = b->geom.width.max;
   else if (w < b->geom.width.min)
      w = b->geom.width.min;
   if (h > b->geom.height.max)
      h = b->geom.height.max;
   else if (h < b->geom.height.min)
      h = b->geom.height.min;
   xo = (w * b->geom.xorigin) >> 10;
   yo = (h * b->geom.yorigin) >> 10;
   x = ((b->geom.xrel * root.w) >> 10) + b->geom.xabs - xo;
   y = ((b->geom.yrel * root.h) >> 10) + b->geom.yabs - yo;
   b->x = x;
   b->y = y;
   b->w = w;
   b->h = h;
   EDBUG_RETURN_;
}

void
SimpleShowButton(Button * b)
{
   char                move, resize;

   EDBUG(4, "SimpleShowButton");
   CalcButton(b);
   move = 0;
   resize = 0;
   if ((b->x != b->cx) || (b->y != b->cy))
      move = 1;
   if ((b->w != b->cw) || (b->h != b->ch))
      resize = 1;
   if ((move) && (resize))
      XMoveResizeWindow(disp, b->win, b->x, b->y, b->w, b->h);
   else if (move)
      XMoveWindow(disp, b->win, b->x, b->y);
   else if (resize)
      XResizeWindow(disp, b->win, b->w, b->h);
   if (b->sticky)
      XRaiseWindow(disp, b->win);
   DrawButon(b);
   b->visible = 1;
   XMapWindow(disp, b->win);
   b->cx = b->x;
   b->cy = b->y;
   b->cw = b->w;
   b->ch = b->h;
   EDBUG_RETURN_;
}

void
ShowButton(Button * b)
{
   char                move, resize;

   EDBUG(4, "ShowButton");
   CalcButton(b);
   move = 0;
   resize = 0;
   if ((b->x != b->cx) || (b->y != b->cy))
      move = 1;
   if ((b->w != b->cw) || (b->h != b->ch))
      resize = 1;
   if ((move) && (resize))
      XMoveResizeWindow(disp, b->win, b->x, b->y, b->w, b->h);
   else if (move)
      XMoveWindow(disp, b->win, b->x, b->y);
   else if (resize)
      XResizeWindow(disp, b->win, b->w, b->h);
   if (b->sticky)
      XRaiseWindow(disp, b->win);
   DrawButon(b);
   b->visible = 1;
   XMapWindow(disp, b->win);
   b->cx = b->x;
   b->cy = b->y;
   b->cw = b->w;
   b->ch = b->h;
   StackDesktops();
   EDBUG_RETURN_;
}

void
MoveButtonToDesktop(Button * b, int num)
{
   EDBUG(3, "MoveButtonToDesktop");
   if (b->sticky)
     {
	b->desktop = 0;
	XReparentWindow(disp, b->win, desks.desk[0].win, b->x, b->y);
	XRaiseWindow(disp, b->win);
     }
   else
     {
	b->desktop = num;
	XReparentWindow(disp, b->win, desks.desk[num & 0x1f].win, b->x, b->y);
     }
   StackDesktops();
   EDBUG_RETURN_;
}

void
HideButton(Button * b)
{
   EDBUG(3, "HideButton");
   XUnmapWindow(disp, b->win);
   b->visible = 0;
   EDBUG_RETURN_;
}

void
DrawButon(Button * b)
{
   EDBUG(3, "DrawButon");
   IclassApply(b->iclass, b->win, b->w, b->h, 0, b->state, 0);
   EDBUG_RETURN_;
}

void
MovebuttonToCoord(Button * b, int x, int y)
{
   int                 rx, ry, relx, rely, absx, absy;
   char                move, resize;

   EDBUG(3, "MovebuttonToCoord");
   if (b->flags & FLAG_FIXED)
      EDBUG_RETURN_;

   if ((x + (b->w >> 1)) < (root.w / 3))
      relx = 0;
   else if ((x + (b->w >> 1)) > ((root.w * 2) / 3))
      relx = 1024;
   else
      relx = 512;
   rx = (relx * root.w) >> 10;
   absx = x - rx;
   if ((y + (b->h >> 1)) < (root.h / 3))
      rely = 0;
   else if ((y + (b->h >> 1)) > ((root.h * 2) / 3))
      rely = 1024;
   else
      rely = 512;
   ry = (rely * root.h) >> 10;
   absy = y - ry;
   if (!(b->flags & FLAG_FIXED_HORIZ))
     {
	b->geom.xorigin = 0;
	b->geom.xabs = absx;
	b->geom.xrel = relx;
     }
   if (!(b->flags & FLAG_FIXED_VERT))
     {
	b->geom.yorigin = 0;
	b->geom.yabs = absy;
	b->geom.yrel = rely;
     }
   CalcButton(b);
   move = 0;
   resize = 0;
   if ((b->x != b->cx) || (b->y != b->cy))
      move = 1;
   if ((b->w != b->cw) || (b->h != b->ch))
      resize = 1;
   if ((move) && (resize))
      XMoveResizeWindow(disp, b->win, b->x, b->y, b->w, b->h);
   else if (move)
      XMoveWindow(disp, b->win, b->x, b->y);
   else if (resize)
      XResizeWindow(disp, b->win, b->w, b->h);
   if (b->sticky)
      XRaiseWindow(disp, b->win);
   b->cx = b->x;
   b->cy = b->y;
   b->cw = b->w;
   b->ch = b->h;
   StackDesktops();
   EDBUG_RETURN_;
}
