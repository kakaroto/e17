#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <unistd.h>
#include <Evas.h>
#include <Ecore.h>

#define MAX_EVAS_COLORS (216)
#define MAX_FONT_CACHE (512 * 1024)
#define MAX_IMAGE_CACHE (1 * (1024 * 1024))
#define FONT_DIRECTORY "./"
#define RENDER_ENGINE RENDER_METHOD_ALPHA_SOFTWARE
/* #define RENDER_ENGINE RENDER_METHOD_BASIC_HARDWARE */
/* #define RENDER_ENGINE RENDER_METHOD_3D_HARDWARE */

/* general functions */
double get_time (void);
void setup(void);

/* callbacks for evas handling */
/* timeout called every now and again for animation */
static void e_timeout(int val, void *data);
/* when the event queue goes idle call this */
static void e_idle(void *data);
/* when the window gets exposed call this */
static void e_window_expose(Eevent * ev);

/* globals */
Evas_Object o_cube;
Evas_Object o_bg;
Evas evas;
Evas_Render_Method render_method = RENDER_ENGINE;

/* callbacks */
static void
e_timeout(int val, void *data)
{
   int i;
   double v;
   static double start = 0.0;
   
   if (start == 0.0) start = get_time();
   v = (get_time() - start) / 10;
   evas_set_color(evas, o_cube, 
		  ((int)((sin(v    ) + 1.0) * 127.5)) & 0xff,
		  ((int)((sin(v * 2) + 1.0) * 127.5)) & 0xff,
		  ((int)((sin(v / 2) + 1.0) * 127.5)) & 0xff,
		  ((int)((sin(v / 8) + 1.0) * 127.5)) & 0xff);
   e_add_event_timer("e_timeout()", 0.10, e_timeout, val + 1, NULL);
}

static void
e_idle(void *data)
{
   evas_render(evas);
}

static void 
e_window_expose(Eevent * ev)
{
   Ev_Window_Expose      *e;
   
   e = (Ev_Window_Expose *)ev->event;
   evas_update_rect(evas, e->x, e->y, e->w, e->h);
}

/* utils */
double
get_time(void)
{
   struct timeval      timev;
   
   gettimeofday(&timev, NULL);
   return (double)timev.tv_sec + (((double)timev.tv_usec) / 1000000);
}

/* meat */
void
setup(void)
{
   Window win, ewin;
   int i, w, h;
   
   /* setup callbacks for events */
   e_event_filter_handler_add(EV_WINDOW_EXPOSE,            e_window_expose);
   /* handler for when the event queue goes idle */
   e_event_filter_idle_handler_add(e_idle, NULL);
   /* create a 400x300 toplevel window */
   win = e_window_new(0, 0, 0, 400, 400);
   
   /* create a 400x300 evas rendering in software - conveience function that */
   /* also creates the window for us in the right colormap & visual */
   evas = evas_new_all(e_display_get(), win, 0, 0, 400, 400, render_method,
		       MAX_EVAS_COLORS, MAX_FONT_CACHE, MAX_IMAGE_CACHE,
		       FONT_DIRECTORY);
   /* get the window ID for the evas created for us */
   ewin = evas_get_window(evas);
  
   /* show the evas window */
   e_window_show(ewin);
   /* set the events this window accepts */
   e_window_set_events(ewin, XEV_EXPOSE | XEV_BUTTON | XEV_MOUSE_MOVE);
   /* show the toplevel */
   e_window_show(win);
   
   /* now... create objects in the evas */
   o_bg = evas_add_image_from_file(evas, "bg.png");   
   evas_move(evas, o_bg, 0, 0);
   evas_resize(evas, o_bg, 400, 400);
   evas_show(evas, o_bg);

   o_cube = evas_add_image_from_file(evas, "cube.png");
   evas_get_image_size(evas, o_cube, &w, &h);
   evas_move(evas, o_cube, (400 - (double)w) / 2.0, (400 - (double)h) / 2.0);
   evas_show(evas, o_cube);

/*   
   evas_set_color(evas, o_cube, 255, 0, 0, 255);
   evas_set_color(evas, o_cube, 255, 255, 0, 255);
   evas_set_color(evas, o_cube, 0, 0, 255, 255);
   evas_set_color(evas, o_cube, 255, 255, 255, 128);
   evas_set_color(evas, o_cube, 128, 128, 128, 255);
 */
/*   
   evas_set_color(evas, o_cube, 128, 0, 0, 128);
 */
}

int 
main(int argc, char **argv)
{
   /* command line parsing */
     {
	int i;
	
	for (i = 1; i < argc; i++)
	  {
	     if (!strcmp(argv[i], "soft")) 
	       render_method = RENDER_METHOD_ALPHA_SOFTWARE;
	     if (!strcmp(argv[i], "x11")) 
	       render_method = RENDER_METHOD_BASIC_HARDWARE;
	     if (!strcmp(argv[i], "hard")) 
	       render_method = RENDER_METHOD_3D_HARDWARE;
	  }
     }
   /* init X */
   e_display_init(NULL);
   /* setup handlers for system signals */
   e_ev_signal_init();
   /* setup the event filter */
   e_event_filter_init();
   /* setup the X event internals */
   e_ev_x_init();

   /* program does its data setup here */
   setup();
   /* and now loop forever handling events */
   e_timeout(0, NULL);
   e_event_loop();
}
