#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <unistd.h>
#include <Evas.h>
#include <Ecore.h>

#define MAX_EVAS_COLORS (216)
#define MAX_FONT_CACHE (512 * 1024)
#define MAX_IMAGE_CACHE (1 * (1024 * 1024))
#define FONT_DIRECTORY "./"
#define RENDER_ENGINE RENDER_METHOD_ALPHA_SOFTWARE
/* #define RENDER_ENGINE RENDER_METHOD_BASIC_HARDWARE */
/* #define RENDER_ENGINE RENDER_METHOD_3D_HARDWARE */

/* general functions */
double get_time (void);
void setup(void);

/* callbacks for evas handling */
/* timeout called every now and again for animation */
static void e_timeout(int v, void *data);
/* when the event queue goes idle call this */
static void e_idle(void *data);
/* when the window gets exposed call this */
static void e_window_expose(Eevent * ev);
/* when the mouse moves in the window call this */
static void e_mouse_move(Eevent * ev);
/* when a mouse button goes down in the window call this */
static void e_mouse_down(Eevent * ev);
/* when a mouse button is released in the window call this */
static void e_mouse_up(Eevent * ev);

/* globals */
Evas_Object o_bg, o_logo, o_logo_sh, o_text;
Evas_Object o_b1, o_b1_sh;
Evas_Object o_b2, o_b2_sh;
Evas_Object o_b3, o_b3_sh;
Evas evas;
Evas_Render_Method render_method = RENDER_ENGINE;
int max_colors = MAX_EVAS_COLORS;
double start = 0.0;
double end = 10.0;
Window main_win;

/* callbacks */
static void
e_timeout(int v, void *data)
{
   int i;
   double val;
   double x, y, z, r;
   int mouse_x, mouse_y;
   int w, h;
   
   mouse_x = 0;
   mouse_y = 0;
   
   if (start == 0.0) start = get_time();
   val = get_time() - start;  
   
   r = (end - val) / end;   
   evas_set_color(evas, o_text, 0, 0, 0, 255 - (255 * r));
   
   if (val > end)
     val = 0.0;
   else
     val *= ((end - val) * (end - val)) / (end * end);
   
   val += 3.0;
   
   r = 48;
   z = ((2 + sin(val * 6 + (3.14159 * 0))) / 3) * 64;
   x = (r + 32) + (cos(val * 4 + (3.14159 * 0)) * r) - (z / 2);
   y = (r + 32) + (sin(val * 6 + (3.14159 * 0)) * r) - (z / 2);
   evas_resize(evas, o_b1, z, z);
   evas_set_image_fill(evas, o_b1, 0, 0, z, z);
   evas_move(evas, o_b1, x, y);
   evas_resize(evas, o_b1_sh, z, z);
   evas_set_image_fill(evas, o_b1_sh, 0, 0, z, z);
   evas_move(evas, o_b1_sh,
	     x - ((mouse_x - (x + (z / 2))) / 16) + (z / 2),
	     y - ((mouse_y - (y + (z / 2))) / 16) + (z / 2));
   z = ((2 + sin(val * 6 + (3.14159 * 0.66))) / 3) * 64;
   x = (r + 32) + (cos(val * 4 + (3.14159 * 0.66)) * r) - (z / 2);
   y = (r + 32) + (sin(val * 6 + (3.14159 * 0.66)) * r) - (z / 2);
   evas_resize(evas, o_b2, z, z);
   evas_set_image_fill(evas, o_b2, 0, 0, z, z);
   evas_move(evas, o_b2, x, y);
   evas_resize(evas, o_b2_sh, z, z);
   evas_set_image_fill(evas, o_b2_sh, 0, 0, z, z);
   evas_move(evas, o_b2_sh,
	     x - ((mouse_x - (x + (z / 2))) / 16) + (z / 2),
	     y - ((mouse_y - (y + (z / 2))) / 16) + (z / 2));
   z = ((2 + sin(val * 6 + (3.14159 * 1.33))) / 3) * 64;
   x = (r + 32) + (cos(val * 4 + (3.14159 * 1.33)) * r) - (z / 2);
   y = (r + 32) + (sin(val * 6 + (3.14159 * 1.33)) * r) - (z / 2);
   evas_resize(evas, o_b3, z, z);
   evas_set_image_fill(evas, o_b3, 0, 0, z, z);
   evas_move(evas, o_b3, x, y);
   evas_resize(evas, o_b3_sh, z, z);
   evas_set_image_fill(evas, o_b3_sh, 0, 0, z, z);
   evas_move(evas, o_b3_sh,
	     x - ((mouse_x - (x + (z / 2))) / 16) + (z / 2),
	     y - ((mouse_y - (y + (z / 2))) / 16) + (z / 2));
   
   e_add_event_timer("e_timeout()", 0.01, e_timeout, val + 1, NULL);
}

static void
e_idle(void *data)
{
   evas_render(evas);
}

static void 
e_window_expose(Eevent * ev)
{
   Ev_Window_Expose      *e;
   
   e = (Ev_Window_Expose *)ev->event;
   evas_update_rect(evas, e->x, e->y, e->w, e->h);
}

static void 
e_mouse_move(Eevent * ev)
{
   Ev_Mouse_Move      *e;
   
   e = (Ev_Mouse_Move *)ev->event;
   evas_event_move(evas, e->x, e->y);
}

static void 
e_mouse_down(Eevent * ev)
{
   Ev_Mouse_Down      *e;
   
   e = (Ev_Mouse_Down *)ev->event;
   evas_event_button_down(evas, e->x, e->y, e->button);
}

static void 
e_mouse_up(Eevent * ev)
{
   Ev_Mouse_Up      *e;
   
   e = (Ev_Mouse_Up *)ev->event;
   evas_event_button_up(evas, e->x, e->y, e->button);
}

static void 
e_window_configure(Eevent * ev)
{
   Ev_Window_Configure *e;
   
   e = (Ev_Window_Configure *)ev->event;
   if (e->win == main_win)
     {
	e_window_resize(evas_get_window(evas), e->w, e->h);
	evas_set_output_size(evas, e->w, e->h);
     }
}
/* callbacks evas will call for events within the evas */

static void
mouse_down(void *_data, Evas _e, Evas_Object _o, int _b, int _x, int _y)
{
   double x, y;
   
   evas_get_geometry(_e, _o, &x, &y, NULL, NULL);
   evas_move(_e, _o, x + 16.0, y + 16.0);
}

static void
mouse_up (void *_data, Evas _e, Evas_Object _o, int _b, int _x, int _y)
{
   double x, y;
   
   evas_get_geometry(_e, _o, &x, &y, NULL, NULL);
   evas_move(_e, _o, x - 16.0, y - 16.0);
   start = 0.0;
}

static void
mouse_move (void *_data, Evas _e, Evas_Object _o, int _b, int _x, int _y)
{
}

static void
mouse_in (void *_data, Evas _e, Evas_Object _o, int _b, int _x, int _y)
{
}

static void
mouse_out (void *_data, Evas _e, Evas_Object _o, int _b, int _x, int _y)
{
}

/* utils */
double
get_time(void)
{
   struct timeval      timev;
   
   gettimeofday(&timev, NULL);
   return (double)timev.tv_sec + (((double)timev.tv_usec) / 1000000);
}

/* meat */
void
setup(void)
{
   Window win, ewin;
   int i;
   
   /* setup callbacks for events */
   e_event_filter_handler_add(EV_WINDOW_EXPOSE,            e_window_expose);
   e_event_filter_handler_add(EV_MOUSE_MOVE,               e_mouse_move);
   e_event_filter_handler_add(EV_MOUSE_DOWN,               e_mouse_down);
   e_event_filter_handler_add(EV_MOUSE_UP,                 e_mouse_up);
   e_event_filter_handler_add(EV_WINDOW_CONFIGURE,         e_window_configure);
   /* handler for when the event queue goes idle */
   e_event_filter_idle_handler_add(e_idle, NULL);
   /* create a 400x300 toplevel window */
   win = e_window_new(0, 0, 0, 400, 400);
   e_window_set_events(win, XEV_CONFIGURE);
   main_win = win;
   
   /* create a 400x300 evas rendering in software - conveience function that */
   /* also creates the window for us in the right colormap & visual */
   evas = evas_new_all(e_display_get(), win, 0, 0, 400, 400, render_method,
		       max_colors, MAX_FONT_CACHE, MAX_IMAGE_CACHE,
		       FONT_DIRECTORY);
   /* get the window ID for the evas created for us */
   ewin = evas_get_window(evas);
  
   /* show the evas window */
   e_window_show(ewin);
   /* set the events this window accepts */
   e_window_set_events(ewin, XEV_EXPOSE | XEV_BUTTON | XEV_MOUSE_MOVE);
   /* show the toplevel */
   e_window_show(win);
   
   /* now... create objects in the evas */
   o_bg = evas_add_image_from_file(evas, "background.png");   
   evas_move(evas, o_bg, 0, 0);
   evas_resize(evas, o_bg, 400, 400);

   o_logo_sh = evas_add_image_from_file(evas, "logo_shadow.png");
   o_logo = evas_add_image_from_file(evas, "logo.png");

   o_b1_sh = evas_add_image_from_file(evas, "bubble_shadow.png");
   o_b2_sh = evas_add_image_from_file(evas, "bubble_shadow.png");
   o_b3_sh = evas_add_image_from_file(evas, "bubble_shadow.png");

   o_b1 = evas_add_image_from_file(evas, "bubble.png");
   o_b2 = evas_add_image_from_file(evas, "bubble.png");
   o_b3 = evas_add_image_from_file(evas, "bubble.png");
   
   o_text = evas_add_text(evas, "notepad", 20, ". . .  the one you love.");
   evas_set_color(evas, o_text, 0, 0, 0, 160);
   
     {
	double w, h;
	
	evas_get_image_size(evas, o_logo, &w, &h);	
	evas_move(evas, o_logo, (400 - w) / 2, 400 - h - 16);
	evas_move(evas, o_logo_sh, ((400 - w) / 2) + 16, 400 - h - 16 + 16);
	w = evas_get_text_width(evas, o_text);
	h = evas_get_text_height(evas, o_text);
	evas_move(evas, o_text, (400 - w) / 2, 400 - h - 4);
     }
   
   evas_show(evas, o_bg);
   evas_show(evas, o_logo_sh);
   evas_show(evas, o_logo);
   evas_show(evas, o_b1_sh);
   evas_show(evas, o_b2_sh);
   evas_show(evas, o_b3_sh);
   evas_show(evas, o_b1);
   evas_show(evas, o_b2);
   evas_show(evas, o_b3);
   evas_show(evas, o_text);

   evas_callback_add(evas, o_logo, CALLBACK_MOUSE_DOWN, mouse_down, NULL);
   evas_callback_add(evas, o_logo, CALLBACK_MOUSE_UP, mouse_up, NULL);
   evas_callback_add(evas, o_logo, CALLBACK_MOUSE_MOVE, mouse_move, NULL);
   evas_callback_add(evas, o_logo, CALLBACK_MOUSE_IN, mouse_in, NULL);
   evas_callback_add(evas, o_logo, CALLBACK_MOUSE_OUT, mouse_out, NULL);
}

int 
main(int argc, char **argv)
{
   /* command line parsing */
     {
	int i;
	
	for (i = 1; i < argc; i++)
	  {
	     if (!strcmp(argv[i], "soft")) 
	       render_method = RENDER_METHOD_ALPHA_SOFTWARE;
	     else if (!strcmp(argv[i], "x11")) 
	       render_method = RENDER_METHOD_BASIC_HARDWARE;
	     else if (!strcmp(argv[i], "hard")) 
	       render_method = RENDER_METHOD_3D_HARDWARE;
	     else
	       max_colors = atoi(argv[i]);
	  }
     }
   /* init X */
   e_display_init(NULL);
   /* setup handlers for system signals */
   e_ev_signal_init();
   /* setup the event filter */
   e_event_filter_init();
   /* setup the X event internals */
   e_ev_x_init();

   /* program does its data setup here */
   setup();
   /* call the animator once to start it up */
   e_timeout(0, NULL);
   /* and now loop forever handling events */
   e_event_loop();
}
